const slug = 'heading';
export default slug;
