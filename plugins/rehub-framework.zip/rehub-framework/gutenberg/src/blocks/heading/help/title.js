const {__} = wp.i18n;
const title = __('Heading', 'rehub-theme-child');
export default title;
