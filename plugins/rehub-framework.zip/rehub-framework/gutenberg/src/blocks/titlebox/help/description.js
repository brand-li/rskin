const {__} = wp.i18n;
const description = __('Bordered Box with title', 'rehub-theme-child');
export default description;

