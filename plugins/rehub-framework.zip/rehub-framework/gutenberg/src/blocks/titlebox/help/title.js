const {__} = wp.i18n;
const title = __('Title box', 'rehub-theme-child');
export default title;
